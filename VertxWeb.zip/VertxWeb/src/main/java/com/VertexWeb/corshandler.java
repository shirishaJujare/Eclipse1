package com.VertexWeb;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.CorsHandler;

public class corshandler extends AbstractVerticle {
	

	@Override
	public void start() throws Exception {
	Router router = Router.router(vertx);

	//Config CORS
	router.route().handler(CorsHandler.create("*")
	.allowedMethod(HttpMethod.GET)
	.allowedHeader("Content-Type"));

	// hello endpoint
	router.get("/api/hello/:name").handler(ctx -> {

	ctx.response().end((ctx.request().getParam("name")));
	});
	vertx.createHttpServer().requestHandler(router).listen(8080);
	}
	
}