package com.VertexWeb;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

public class Bodyhandler extends  AbstractVerticle {
	
	
	@Override
	public void start() throws Exception {
		
	 Router router = Router.router(vertx);
	 
	 vertx.createHttpServer().requestHandler(router).listen(8090);
	 System.out.println("server started at 8090");
	 
	 router.route().handler(BodyHandler.create());
	 router.route("/").handler(routingContext -> {
		 JsonObject json = new JsonObject()
		 .put("message","hello world");
	  routingContext.response()
	  .putHeader("content-type","application/json; charset=UTF8")
	  .end(json.encodePrettily() );
	
	  
	 });
	}
	 
}
