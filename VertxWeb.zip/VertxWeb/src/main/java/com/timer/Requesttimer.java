package com.timer;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;

public class Requesttimer  extends AbstractVerticle {
	
	public static void main(String args[]) {
		
		Vertx vertx=Vertx.vertx();

	WebClient client = WebClient.create(vertx);
	   
	
	client
	  .get(8081, "mycompany.com", "https://horizon.mycompany.com/?domainName=finance&userName=fred")
	  .timeout(5000)
	  .send()
	  .onSuccess(response -> System.out
			    .println("Received response with status code" + response.statusCode()))
	  .onFailure(err ->
	    System.out.println("Something went wrong " + err.getMessage()));
	}
}