package com.timer;

import io.vertx.core.AbstractVerticle;

public class Timer extends AbstractVerticle{
	
	private static int counter = 0;
	@Override
	public void start() throws Exception {
		System.out.println("PeriodicVerticle.start()");
		
		vertx.setTimer(1000, handler->{
			System.out.println("I am delayed by 1 second");
		});
		

        long timerId = vertx.setPeriodic(2000, id -> {
            System.out.println("Hello " + ++counter);
            if (counter == 5) {
                System.out.println("PeriodicVerticl.stop()");
                vertx.cancelTimer(id);
            }
	});
 }
} 
		

