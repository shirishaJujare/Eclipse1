package com.content;

import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Promise;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;

public class RestApiVerticle extends AbstractVerticle {

    @Override
    public void start(Future<Void> startFuture) throws Exception {

        Router router = Router.router(vertx);

        router.route().handler(ctx -> {
            ctx.response()
                .putHeader("Cache-Control", "no-store, no-cache");
            ctx.next();             
        });

        router.route("/api*")
            .produces("application/json")
            .consumes("application/json")
            .failureHandler(ctx -> {

                final JsonObject json = new JsonObject()
                .put("timestamp", System.nanoTime())
                .put("status", ctx.statusCode())
                .put("error", HttpResponseStatus.valueOf(ctx.statusCode()).reasonPhrase())
                .put("path", ctx.request().path());

                final String message = ctx.get("message");

                if(message != null) {
                    json.put("message", message);
                }

                ctx.response().putHeader(HttpHeaders.CONTENT_TYPE,"application/json; charset=utf-8");
                ctx.response().end(json.encodePrettily());          

            });

        router.get("/api/greeting")
            .produces("application/json")
            .consumes("application/json")
            .handler(ctx -> {

                final JsonObject greeting = new JsonObject()
                    .put("greeting", "Hello!");

                ctx.response().putHeader(HttpHeaders.CONTENT_TYPE,"application/json; charset=utf-8");
                ctx.response().end(greeting.encodePrettily());

            });

        HttpServer httpServer = vertx.createHttpServer();
        httpServer
            .requestHandler(router::accept)
            .listen(9090, "localhost", listenHandler -> {
                if (listenHandler.succeeded()) {
                    startFuture.complete();
                }
                if(listenHandler.failed()) {
                    startFuture.fail(listenHandler.cause());
                }
                System.out.println("Server started at 9090");
            });
    }
}