package com.vertxwebMethods;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.MultiMap;
import io.vertx.core.http.HttpServer;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;

public class Verticleweb extends AbstractVerticle{
	@Override
	public void start() throws Exception {
		System.out.println("BoostrapVerticle.start()");
		HttpServer server = vertx.createHttpServer();
		
		Router router = Router.router(vertx);
		router.get("/getCustomers").handler(context->{
			JsonObject customer = new JsonObject();
			customer.put("name", "abc");
			customer.put("email","abc@gmail.com");
			context.response().end(customer.encodePrettily());
		});
		
		//put create doc
		//post update doc
		//patch partial update doc
		//delete  delete the doc
		
		
		
		router.post("/createCustomer").handler(BodyHandler.create()).handler(context->{
			
			JsonObject customer = context.getBodyAsJson();
			System.out.println("Got the Customer :"+ customer.toString());
			
			JsonObject res = new JsonObject();
			res.put("message", "customer created successfully");
			context.response().end(res.encodePrettily());
		});
		
		router.put("/updateCustomer").handler(BodyHandler.create()).handler(context->{
			System.out.println("put method");
			JsonObject customer = context.getBodyAsJson();
			System.out.println("Got the Customer :"+ customer.toString());
			
			JsonObject res = new JsonObject();
			res.put("message", "customer updated successfully");
			context.response().end(res.encodePrettily());
		});
		
		router.patch("/patchCustomer").handler(BodyHandler.create()).handler(context->{
			
			JsonObject customer = context.getBodyAsJson();
			System.out.println("Got the Customer :"+ customer.toString());
			
			JsonObject res = new JsonObject();
			res.put("message", "customer created successfully");
			context.response().end(res.encodePrettily());
		});
		
		router.delete("/deleteCustomer").handler(BodyHandler.create()).handler(context->{
//			
			JsonObject customer = context.getBodyAsJson();
			System.out.println(" Customer deleted :"+ customer.toString());
			
			JsonObject res = new JsonObject();
			res.put("message", "customer deleted successfully");
			context.response().end(res.encodePrettily());
		});
		
		// Path Parameters
		
		
		router.get("/getCustomer/:id/:name/:email").handler(context->{
			
			String id = context.request().getParam("id");
			String name = context.request().getParam("name");
			String email = context.request().getParam("email");
			
			System.out.println("ID is:"+id);
			System.out.println("Name is:"+name);
			System.out.println("Email is:"+email);
			
			JsonObject customer = new JsonObject();
			customer.put("name", "shirisha");
			customer.put("email", "siri@gmail.com");
			
			customer.put("name", "prathiksha");
			customer.put("email", "prathi@gmail.com");
			
			
			
			context.response().end(customer.encodePrettily());
		});
		
		// Query Parameters
		router.get("/fetchCustomer").handler(context->{
			
			MultiMap params = context.request().params();
			String name =  params.get("name");
			String email =  params.get("email");
			System.out.println("Query Param Name : "+name);
			System.out.println("Query Param Email : "+email);
			JsonObject customer = new JsonObject();
			customer.put("name", "shirisha");
			customer.put("email", "siri@gmail.com");
			context.response().end(customer.encodePrettily());
		});
		server.requestHandler(router).listen(8080);
		System.out.println("server started");
	}
}