package com.Routingcontext;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.StaticHandler;
import io.vertx.ext.web.handler.TemplateHandler;

/**
 * @author <a href="http://tfox.org">Tim Fox</a>
 */
public class Retriev  extends AbstractVerticle{
	
	@Override
	  public void start() {

	    Router router = Router.router(vertx);

	    // Serve the dynamic pages
	    router.route("/static/*")
	      .handler(ctx -> {
	        // put the context into the template render context
	        ctx.put("context", ctx);
	        ctx.next();
	        JsonObject json = new JsonObject()
	        .put("message","hello world");
	        ctx.response()
	        .putHeader("Content-Type", "application/json; charset=UTF8");
	        
	      });
	      

	    // Serve the static pages
	    router.route().handler(StaticHandler.create());

	    vertx.createHttpServer().requestHandler(router).listen(8080);
	  }


}