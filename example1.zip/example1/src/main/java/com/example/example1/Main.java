package com.example.example1;

import io.vertx.core.Vertx;

public class Main {

	public static void main(String args[]) {
		Vertx vertx=Vertx.vertx();
		MainVerticle mv= new MainVerticle();
		vertx.deployVerticle(mv);

		}
}
